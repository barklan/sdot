# Changelog

## [unreleased]

### Features
- custom custom blink.cmp kind name, highlight, and icon

### Bug Fixes
- sort fetched crate versions (#156)
