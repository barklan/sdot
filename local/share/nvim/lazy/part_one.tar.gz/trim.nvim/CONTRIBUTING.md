# Contributing

## Submitting a new pattern for trimming

You can add patterns to [trim\.nvim/config\.lua at master · cappyzawa/trim\.nvim](https://github.com/cappyzawa/trim.nvim/blob/master/lua/trim/config.lua).

Thanks!
