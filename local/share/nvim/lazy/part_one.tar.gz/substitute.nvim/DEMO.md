# In action

## Substitute operator

![substitute operator](https://user-images.githubusercontent.com/3751019/153144389-e96f0cd4-6151-43ec-96d1-722cd6a4dcca.gif)

## Substitute range

![substitute range](https://user-images.githubusercontent.com/3751019/153144412-7be1a5b7-e233-4947-8dfc-37fdedbc1ba0.gif)

## Exchange operator

![exchange operator](https://user-images.githubusercontent.com/3751019/153144426-f0605cb3-2e6f-44bb-9893-760c99c6c442.gif)
