require('cmp').register_source('nvim_lsp_document_symbol', require('cmp_nvim_lsp_document_symbol').new())
