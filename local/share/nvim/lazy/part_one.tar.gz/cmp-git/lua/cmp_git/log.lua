return require("plenary.log").new({
    plugin = "cmp-git",
})
