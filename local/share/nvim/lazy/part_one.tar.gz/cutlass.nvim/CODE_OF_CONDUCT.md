# Contributor Code of Conduct

[Don't be a jerk.](https://meta.wikimedia.org/wiki/Don%27t_be_a_jerk)
