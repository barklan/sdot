local s = [[
a
  multiline
    string
]]

print [[
test
]]
