func Test() {
  (1 + 2)

  [
    1,
    2,
    3,
    4,
    5
  ].split()

  let x = [
    1: 2,
    3: 4,
  ]

}
