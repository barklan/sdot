void foo(int a,
         int b,
         int c);

void foo(int a,
         int b

