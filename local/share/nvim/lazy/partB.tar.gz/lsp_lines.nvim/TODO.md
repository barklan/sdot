- For entries where column 0 is the issue, the lines don't make sense. This is
  evident for diagnostics for (col=0, row=0), which are usually meant to refer
  to the entire file.
