require'cmp'.register_source('fuzzy_buffer', require'cmp_fuzzy_buffer'.new())

