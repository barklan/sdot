require'cmp'.register_source('fish', require'cmp_fish'.new())
