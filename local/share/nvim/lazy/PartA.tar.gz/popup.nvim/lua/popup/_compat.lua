local compat = {}

return compat
