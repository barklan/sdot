The format examples are referenced from:

- Markdown Example: <https://github.com/crispgm/crispgm.com/blob/master/site/_drafts/test-for-styles.md>
- AsciiDoc Example: <https://asciidoctor.org/docs/asciidoc-article/>
- OrgMode Example: <https://writequit.org/denver-emacs/presentations/files/example.org.html>
- Neorg Example: <https://github.com/nvim-neorg/neorg/blob/main/doc/neorg.norg>
- ReStructuredText Example: <https://fangohr.github.io/computing/rst/rst.txt>
- LaTeX Example: <http://mally.stanford.edu/~sr/computing/latex-example.html>
