# cmp-calc

nvim-cmp source for math calculation.

# Setup

```lua
require'cmp'.setup {
  sources = {
    { name = 'calc' }
  }
}
```

