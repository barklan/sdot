package main

import "fmt"

func extracted() {
	fmt.Errorf("test")
}

func simple_function() {
	fmt.Println("test2")
	fmt.Println("test3")
	fmt.Println("test4")
	fmt.Println("test5")
}
