#include <string>

int main() {
  printf("a");
  printf("b");
  return 0;
}
