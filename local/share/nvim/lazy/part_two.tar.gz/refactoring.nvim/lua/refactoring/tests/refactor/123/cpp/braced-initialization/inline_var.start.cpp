int main() {
  int x{1};
  int y = x + 1;
}
