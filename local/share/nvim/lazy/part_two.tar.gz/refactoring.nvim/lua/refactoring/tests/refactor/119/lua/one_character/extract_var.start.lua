-- stylua: ignore start

print("a")
print("b")
