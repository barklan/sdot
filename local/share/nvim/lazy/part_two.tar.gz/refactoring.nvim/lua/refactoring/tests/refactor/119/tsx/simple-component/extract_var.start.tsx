function foo(name: string) {
    return (
        <div>
            <p>Name:{name}</p>
            <p>Hello: {name}</p>
        </div>
    );
}
