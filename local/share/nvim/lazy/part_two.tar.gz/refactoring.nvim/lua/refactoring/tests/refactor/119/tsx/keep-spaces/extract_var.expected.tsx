function foo(name: string) {
    const foo = <a download href="/hello.jpg">
                download
            </a>;
    return (
        <div>
            {foo}
        </div>
    );
}
