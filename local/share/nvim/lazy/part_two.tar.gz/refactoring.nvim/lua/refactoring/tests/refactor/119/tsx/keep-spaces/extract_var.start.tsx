function foo(name: string) {
    return (
        <div>
            <a download href="/hello.jpg">
                download
            </a>
        </div>
    );
}
