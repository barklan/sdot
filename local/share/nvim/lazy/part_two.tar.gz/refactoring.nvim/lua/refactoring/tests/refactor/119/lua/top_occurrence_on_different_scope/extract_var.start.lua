local function foo()
    print("foo")
    if true then
        print("foo")
    end
end
