
local foo = require'foo'
foo.bar.baz()
