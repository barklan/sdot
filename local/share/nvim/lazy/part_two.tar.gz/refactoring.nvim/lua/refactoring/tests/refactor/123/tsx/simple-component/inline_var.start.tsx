function foo(name: string) {
    const foo = <p>Name: {name}</p>;
    return (
        <div>
            {foo}
            <p>Hello: {name}</p>
        </div>
    );
}
