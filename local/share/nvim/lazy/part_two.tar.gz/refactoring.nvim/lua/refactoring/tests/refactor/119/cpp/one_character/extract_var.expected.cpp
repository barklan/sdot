#include <string>

int main() {
  auto foo = "a";
  printf(foo);
  printf("b");
  return 0;
}
