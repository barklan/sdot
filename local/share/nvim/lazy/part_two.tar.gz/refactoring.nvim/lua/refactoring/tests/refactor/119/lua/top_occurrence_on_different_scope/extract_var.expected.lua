local function foo()
    local foo = "foo"
    print(foo)
    if true then
        print(foo)
    end
end
