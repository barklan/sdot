-- stylua: ignore start


require'foo'.bar.baz()
