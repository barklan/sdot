

require'foo'.bar.baz()
