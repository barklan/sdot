
local greeting = "hello world"
print(greeting)
