-- stylua: ignore start

local greeting = "hello world"
print(greeting)
