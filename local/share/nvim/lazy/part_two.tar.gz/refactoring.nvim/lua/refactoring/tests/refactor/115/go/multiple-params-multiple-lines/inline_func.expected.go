package main

import "fmt"



func simple_function() {
    a := 99
    a := 1
    b := 2
    c := 3
    fmt.Println(a + b + c)
    fmt.Println(a)
}
