-- stylua: ignore start

print("hello world")
