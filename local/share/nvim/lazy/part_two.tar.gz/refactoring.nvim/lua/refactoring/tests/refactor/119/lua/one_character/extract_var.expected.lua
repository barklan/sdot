
local foo = "a"
print(foo)
print("b")
