-- stylua: ignore start

local foo = "a"
print(foo)
print("b")
