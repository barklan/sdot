
<script lang="ts">
import { onMount } from 'svelte';
let data = 'sdada';
let loading = true;
function toggle() {
  loading = !loading;
}
onMount(() => {

});
</script>

<div class="w-screen h-screen">
  <div class="w-100 bg-blue-400 h-72 pt-2">


  <visual></lala>





  </div>
</div>
