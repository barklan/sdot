-- {{TEST}}

local function foo() -- {{CONTEXT}}

  local function bar() -- {{CONTEXT}}



   -- {{CURSOR}}

  end

end
