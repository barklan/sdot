struct Struct {
    int *f1;
    int *f2;



    // cursor position 1
};








class Class {
    int *f1;
    int *f2;



    // cursor position 2
};








typedef enum {
  E1,
  E2,
  E3


  // cursor position 3
} myenum;










int main(int arg1,
         char **arg2,
         char **arg3
         )
{
  if (arg1 == 4
      && arg2 == arg3) {
    for (int i = 0; i < arg1; i++) {
      while (1) {





        // cursor position 4
      }
    }
  }






  do {
    int array[1];
    for (auto value : array) {





      // cursor position 5
    }
  } while (1);
}
