# (for)
for (x in 1:10) {





  print(x)
}

# (while)
i <- 1
while (i < 6) {






  print(i)
  i <- i + 1
}

# (if)
if (b > a) {





  print("b is greater than a")
} else if (a == b) {




  print("a and b are equal")
} else {





  print("a is greater than b")
}

# (left_assignment)
left_assign <- list("a",





  "b")

# (equals_assignment)
equals_assign = list("a",





  "b")


# (super_assignment)
super_assign <<- list("a",





  "b")

# (binary)
mtcars %>%




  mt

# (call)
library(






ggplot2)

# (function_definition)

function(foo, bar) {






  print(foo)
  print(bar)
}
