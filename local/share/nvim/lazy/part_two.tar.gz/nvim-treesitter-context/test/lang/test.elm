module Test exposing (..)

import Html exposing (div, text)


main : Html.Html msg
main =
    let
        test =
            "Test content"
    in
    case test of
        "Hello" ->
            div []
                [ text "Hello, World!"
                , -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  -- Generate some lines
                  div []
                    [ text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    , text "Some more lines"
                    ]
                ]

        _ ->
            text "Default"
