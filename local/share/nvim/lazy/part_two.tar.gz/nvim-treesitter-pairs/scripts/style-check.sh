#!/usr/bin/env bash

luacheck `find -name  "*.lua"` --codes
