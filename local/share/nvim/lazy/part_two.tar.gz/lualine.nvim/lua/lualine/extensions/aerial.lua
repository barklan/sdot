-- MIT license, see LICENSE for more details.
-- Extension for aerial.nvim
local M = {}

M.sections = { lualine_a = { 'filetype' } }

M.filetypes = { 'aerial' }

return M
